package com.idfc.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoterIdApplicationTests {

	@Test
	void contextLoads() {
	}

}
