package com.idfc.caapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.idfc.caapp.VerifyVoterIdException;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse;
import com.idfc.caapp.request.VoterIdRequest;
import com.idfc.caapp.transformer.CustomerTransformer;

@Service
public class VoterIdService {
	
	@Autowired
	private IntegrationService integrationService;
	@Autowired
	private CustomerTransformer customerTransformer;
	
	//@CircuitBreaker(name = "ca-customer-service", fallbackMethod = "voterIdServiceMethod")
	public VerifyVoterIdResponse verifyVoterIdDetails(VoterIdRequest voterIdRequest) {
		
		VerifyVoterIdRequest verifyVoterIdRequest = customerTransformer.prepareVerifyVoterIdRequest(voterIdRequest);
		return integrationService.verifyVoterIdDetails(verifyVoterIdRequest);
		
	}
	
	public VerifyVoterIdResponse voterIdServiceMethod(Exception e) {
		throw new VerifyVoterIdException(HttpStatus.NOT_FOUND.value(), "error", "VoterId Service is down");
	}

}
