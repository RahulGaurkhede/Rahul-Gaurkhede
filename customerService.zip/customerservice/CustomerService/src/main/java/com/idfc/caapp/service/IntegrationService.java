package com.idfc.caapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.idfc.caapp.mule.response.VerifyVoterIdRequest;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse;

@Component
public class IntegrationService {
	
	@Value("${mule.url.verify.voterId}")
	private String muleVerifyVoterIdUrl;
	
	@Autowired
	private RestTemplate restTemplate;
	
	public VerifyVoterIdResponse verifyVoterIdDetails(VerifyVoterIdRequest verifyVoterIdRequest) {
		
		return restTemplate.getForObject(muleVerifyVoterIdUrl.concat("/voterId/verifyVoterId"),VerifyVoterIdResponse.class, verifyVoterIdRequest);
		
	}

}
