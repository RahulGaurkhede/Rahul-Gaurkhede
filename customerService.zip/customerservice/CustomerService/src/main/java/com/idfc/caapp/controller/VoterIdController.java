package com.idfc.caapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.idfc.caapp.VerifyVoterIdException;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse;
import com.idfc.caapp.request.VoterIdRequest;
import com.idfc.caapp.response.MessageHeader;
import com.idfc.caapp.response.MessageResponse;
import com.idfc.caapp.response.VoterMessageBody;
import com.idfc.caapp.service.VoterIdService;

@RestController
@RequestMapping("karza")
public class VoterIdController {

	@Autowired
	private VoterIdService voterIdService;


	@SuppressWarnings("static-access")
	@GetMapping(value = "/verifyVoterId", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getVoterIdDetails(@RequestBody VoterIdRequest voterIdRequest) {

		VerifyVoterIdResponse response = voterIdService.verifyVoterIdDetails(voterIdRequest);

		String result = response.getVoterIdVerificationResp().getMsgHdr().getRslt();

		if (result.equalsIgnoreCase("OK")) {

			MessageResponse<?> messageResponse = MessageResponse.builder()
					.messageHeader(MessageHeader.builder().code(Integer.toString(HttpStatus.OK.value())).build())
					.messageBody(VoterMessageBody
							.getVerifyVoterIdDetails(response.getVoterIdVerificationResp().getMsgBdy().getResult()))
					.build();

			return new ResponseEntity<MessageResponse<?>>(messageResponse, HttpStatus.OK);
		} else {

			String errorString = response.getVoterIdVerificationResp().getMsgHdr().getError().get(0).getRsn();
			throw new VerifyVoterIdException(HttpStatus.BAD_REQUEST.value(), "error", errorString);
		}

	}

}
