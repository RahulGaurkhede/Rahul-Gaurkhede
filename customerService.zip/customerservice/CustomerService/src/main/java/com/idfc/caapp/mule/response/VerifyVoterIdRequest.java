package com.idfc.caapp.mule.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class VerifyVoterIdRequest {

	public VoterIdVerificationReq voterIdVerificationReq;

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VoterIdVerificationReq {
		private VerifyVoterIdReqMsgHdr msgHdr;
		private VerifyVoterIdReqMsgBdy msgBdy;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VerifyVoterIdReqMsgHdr {
		private Frm frm;
		private HeaderFields hdrFlds;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class VerifyVoterIdReqMsgBdy {
		private String consent;
		private String epicNumber;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class Frm {
		private String id;
	}

	@NoArgsConstructor
	@AllArgsConstructor
	@Data
	@Builder
	public static class HeaderFields {
		private String msgId;
		private String timestamp;
	}

}
