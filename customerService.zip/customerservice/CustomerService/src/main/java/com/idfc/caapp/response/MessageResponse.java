package com.idfc.caapp.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings({ "unused", "hiding" })
@Builder
public class MessageResponse<VoterMessageBody> {
	
	@JsonProperty(value = "msg_hdr")
	private MessageHeader messageHeader;
	
	@JsonProperty(value = "msg_body")
	private VoterMessageBody messageBody;

}
