package com.idfc.caapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoterIdApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoterIdApplication.class, args);
		System.out.println("Welcome Spring Boot");
	}

}
