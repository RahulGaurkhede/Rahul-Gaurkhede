package com.idfc.caapp;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.idfc.caapp.response.ErrorMessage;
import com.idfc.caapp.response.MessageHeader;
import com.idfc.caapp.response.MessageResponse;

@ControllerAdvice
public class CustomerRestExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler({VerifyVoterIdException.class})
	public ResponseEntity<MessageResponse> customerVoterIdException(VerifyVoterIdException ex) {

		ErrorMessage errorMessage = ErrorMessage.builder().status(ex.getError()).erroorMessage(ex.getErrorMessage())
				.build();
		MessageResponse<?> messageResponse = MessageResponse.builder()
				.messageHeader(MessageHeader.builder().code(Integer.toString(ex.getCode())).build())
				.messageBody(errorMessage).build();
		
		return new ResponseEntity<MessageResponse>(messageResponse, HttpStatus.valueOf(ex.getCode()));
	}

}
