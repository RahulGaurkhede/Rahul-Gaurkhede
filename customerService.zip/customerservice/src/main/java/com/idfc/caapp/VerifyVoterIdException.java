package com.idfc.caapp;

import lombok.Data;

@Data
public class VerifyVoterIdException extends RuntimeException{
	
	private static final long serialVersionUID = 11;
	
	private int code;
	private String error;
	private String errorMessage;
	public VerifyVoterIdException(int code, String error, String errorMessage) {
		
		this.code = code;
		this.error = error;
		this.errorMessage = errorMessage;
	}
	
	

}
