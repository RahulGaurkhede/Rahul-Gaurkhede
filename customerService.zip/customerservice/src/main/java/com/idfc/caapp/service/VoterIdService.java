package com.idfc.caapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.idfc.caapp.VerifyVoterIdException;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.VerifyVoterIdReqMsgHdr;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdDetails;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdMessageBody;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VoterIdVerificationResp;
import com.idfc.caapp.request.VoterIdRequest;
import com.idfc.caapp.transformer.CustomerTransformer;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse.CustomerVoterIdDetails;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse.CustomerVoterIdMessageBody;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse.CustomerVoterIdMessageHeader;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class VoterIdService {

	@Autowired
	private IntegrationService integrationService;
	@Autowired
	private CustomerTransformer customerTransformer;

	@CircuitBreaker(name = "ca-customer-service", fallbackMethod = "voterIdServiceMethod")
	public CustomerVoterIdResponse verifyVoterIdDetails(String voterId) {

		VoterIdRequest voterIdRequest = VoterIdRequest.builder().voterId(voterId).epicNumber("E123").build();
		VerifyVoterIdRequest verifyVoterIdRequest = customerTransformer.prepareVerifyVoterIdRequest(voterIdRequest);
		VerifyVoterIdResponse verifyVoterIdResponse = integrationService.getverifyVoterIdDetails(verifyVoterIdRequest);
		//System.out.println("==getverifyVoterIdDetails==" + verifyVoterIdResponse);
		VerifyVoterIdDetails result = verifyVoterIdResponse.getVoterIdVerificationResp().getMsgBdy().getResult();

		VerifyVoterIdMessageBody requestBody = verifyVoterIdResponse.getVoterIdVerificationResp().getMsgBdy();

		return CustomerVoterIdResponse.builder().msgHdr(CustomerVoterIdMessageHeader.builder().code("200").build())
				.msgBdy(CustomerVoterIdMessageBody.builder()
						.result(CustomerVoterIdDetails.builder().name(result.getName()).rln_name(result.getRln_name())
								.rln_type(result.getRln_type()).gender(result.getGender())
								.district(result.getDistrict()).ac_name(result.getAc_no()).pc_name(result.getPc_name())
								.state(result.getState()).epic_no(result.getEpic_no()).dob(result.getDob())
								.age(result.getAge()).part_no(result.getPart_no()).slno_inpart(result.getSlno_inpart())
								.ps_name(result.getPs_name()).part_name(result.getPart_name())
								.last_update(result.getLast_update()).ps_lat_long(result.getPs_lat_long())
								.rln_name_v1(result.getRln_name_v1()).rln_name_v2(result.getRln_name_v2())
								.rln_name_v3(result.getRln_name_v3()).section_no(result.getSection_no())
								.id(result.getId()).name_v1(result.getName_v1()).name_v2(result.getName_v2())
								.name_v3(result.getName_v3()).ac_no(result.getAc_no()).st_code(result.getSt_code())
								.house_no(result.getHouse_no()).build())
						.request_id(requestBody.getRequest_id()).status_code(requestBody.getStatus_code()).build())
				.build();

		////////////////// **hard coded response**//////////////////
		/*return CustomerVoterIdResponse.builder().msgHdr(CustomerVoterIdMessageHeader.builder().code("200").build())
				.msgBdy(CustomerVoterIdMessageBody.builder()
						.result(CustomerVoterIdDetails.builder().name("").rln_name("").rln_type("").gender("M")
								.district("Nagpur").ac_name("").pc_name("").state("Maharashtra").epic_no("KSG3221710")
								.dob("10-06-1985").age("36").part_no("").slno_inpart("").ps_name("").part_name("")
								.last_update("").ps_lat_long("").rln_name_v1("").rln_name_v2("").rln_name_v3("")
								.section_no("").id("").name_v1("").name_v2("").name_v3("").ac_no("").st_code("")
								.house_no("4526").build())
						.request_id("8124315d").status_code("101").build())
				.build();*/
	}

	public CustomerVoterIdResponse voterIdServiceMethod(Exception e) {
		throw new VerifyVoterIdException(HttpStatus.NOT_FOUND.value(), "error", "VoterId Service is down");
	}

}
