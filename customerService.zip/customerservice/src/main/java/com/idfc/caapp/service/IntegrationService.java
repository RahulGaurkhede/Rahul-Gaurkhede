package com.idfc.caapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.idfc.caapp.mule.response.VerifyVoterIdRequest;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdDetails;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdMessageBody;
import com.idfc.caapp.mule.response.VerifyVoterIdExlResponse;

@Component
public class IntegrationService {

	@Value("${mule.url.verify.voterId}")
	private String muleVerifyVoterIdUrl;

	@Autowired
	private RestTemplate restTemplate;

	public VerifyVoterIdResponse getverifyVoterIdDetails(VerifyVoterIdRequest verifyVoterIdRequest) {

		VerifyVoterIdResponse verifyVoterIdResponse = restTemplate.getForObject(muleVerifyVoterIdUrl,
				VerifyVoterIdResponse.class, verifyVoterIdRequest);

		return verifyVoterIdResponse;
	}

}
