package com.idfc.caapp.response;

import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("unused")
@Builder
public class VoterMessageBody {

	private String name;
	private String rln_name;
	private String rln_type;
	private String gender;
	private String district;
	private String ac_name;
	private String state;
	private String epic_no;
	private String age;
	
	public static VoterMessageBody getVerifyVoterIdDetails(VerifyVoterIdDetails verifyVoterIdDetails) {
		
		return VoterMessageBody.builder().name(verifyVoterIdDetails.getName())
				.rln_name(verifyVoterIdDetails.getRln_name())
				.rln_type(verifyVoterIdDetails.getRln_type())
				.gender(verifyVoterIdDetails.getGender())
				.district(verifyVoterIdDetails.getDistrict())
				.ac_name(verifyVoterIdDetails.getAc_name())
				.state(verifyVoterIdDetails.getState())
				.epic_no(verifyVoterIdDetails.getEpic_no())
				.age(verifyVoterIdDetails.getAge()).build();
	}

}
