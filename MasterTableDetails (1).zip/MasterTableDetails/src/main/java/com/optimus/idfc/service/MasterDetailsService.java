package com.optimus.idfc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.optimus.idfc.VerifyMasterdetailException;
import com.optimus.idfc.Response.MasterDetailResponse;
import com.optimus.idfc.Response.MasterDetailResponse.MassageBody;
import com.optimus.idfc.Response.MasterDetailResponse.MassageHeader;
import com.optimus.idfc.entity.BusinessTypeMaster;
import com.optimus.idfc.entity.City_State_Master;
import com.optimus.idfc.entity.CountryMaster;
import com.optimus.idfc.entity.DocumentMaster;
import com.optimus.idfc.entity.LineOfBusiness;
import com.optimus.idfc.entity.PinCodeMaster;
import com.optimus.idfc.entity.SalutationMaster;
import com.optimus.idfc.repository.BusinessTypeMasterRepository;
import com.optimus.idfc.repository.CityStateMasterRepository;
import com.optimus.idfc.repository.CountrymasterRepository;
import com.optimus.idfc.repository.DocumentMasterRepository;
import com.optimus.idfc.repository.LineOfBusinessRepository;
import com.optimus.idfc.repository.PinCodeMasterRepository;
import com.optimus.idfc.repository.SalutationMasterRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class MasterDetailsService {
	
	@Autowired
	private DocumentMasterRepository documentMasterRepository;
	
	@Autowired
	private BusinessTypeMasterRepository businessTypeMasterRepository;
	
	@Autowired
	private LineOfBusinessRepository lineOfBusinessRepository;
	
	@Autowired
	private CountrymasterRepository countrymasterRepository;
	
	@Autowired
	private CityStateMasterRepository cityStateMasterRepository;
	
	@Autowired
	private PinCodeMasterRepository pinCodeMasterRepository;
	@Autowired
	private SalutationMasterRepository salutationMasterRepository;
	
	private MassageHeader massageHeader;
	private MassageBody massageBody;
	private MasterDetailResponse masterDetailResponse;

	//@CircuitBreaker(name = "master-detail-service", fallbackMethod = "masterdetailServiceMethod")
	public MasterDetailResponse getMasterDetail() {
		List<DocumentMaster> documentMasterList= new ArrayList<DocumentMaster>();
	
		List<BusinessTypeMaster> businessTypeMasteList = new ArrayList<BusinessTypeMaster>();
		
		List<LineOfBusiness> lineOfBusinessList = new ArrayList<LineOfBusiness>();
		
		List<PinCodeMaster> pinCodeMasterList= new ArrayList<PinCodeMaster>();
		
		List<SalutationMaster> SalutationMasterList = new ArrayList<SalutationMaster>();
		
		List<CountryMaster> CountryMasterList = new ArrayList<CountryMaster>();
		
		List<City_State_Master> CityStateMasterList = new ArrayList<City_State_Master>();
		 
		try {
		documentMasterRepository.findAll().forEach(documentMasterList::add);
		businessTypeMasterRepository.findAll().forEach(businessTypeMasteList::add);
		lineOfBusinessRepository.findAll().forEach(lineOfBusinessList::add);
		
		pinCodeMasterRepository.findAll().forEach(pinCodeMasterList::add);
		salutationMasterRepository.findAll().forEach(SalutationMasterList::add);
		countrymasterRepository.findAll().forEach(CountryMasterList::add);
		cityStateMasterRepository.findAll().forEach(CityStateMasterList::add);
		
		
		massageHeader = MassageHeader.builder().code("200").build();
		massageBody = MassageBody.builder().documentList(documentMasterList).busunesssTypeList(businessTypeMasteList).lineOfBusinessList(lineOfBusinessList).CityStateMasterList(CityStateMasterList).CountryMasterList(CountryMasterList).pinCodeMasterList(pinCodeMasterList).SalutationMasterList(SalutationMasterList).build();
		
		masterDetailResponse = MasterDetailResponse.builder().massageHeader(massageHeader).massageBody(massageBody).build();
		}
		catch(Exception ex) {
		  
		}
		return masterDetailResponse;
		
	}
	
	/*
	 * public VerifyMasterdetailException masterdetailServiceMethod(Exception e) {
	 * throw new VerifyMasterdetailException(HttpStatus.NOT_FOUND.value(), "error",
	 * "Master Detail Service is down"); }
	 */
	
}
