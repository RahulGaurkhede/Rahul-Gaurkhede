package com.optimus.idfc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.optimus.idfc.entity.City_State_Master;

@Repository
public interface CityStateMasterRepository extends JpaRepository<City_State_Master, String> {

}
