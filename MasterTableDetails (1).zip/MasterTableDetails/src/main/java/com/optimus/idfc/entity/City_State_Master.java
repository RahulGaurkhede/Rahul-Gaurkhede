package com.optimus.idfc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="City_State_Master")
public class City_State_Master {
	
	@Id
	@Column(name="INST_NO")
	private String INST_NO;
	
	@Column(name="COUNTRY_CODE")
	private String COUNTRY_CODE;
	
	@Column(name="COUNTRY_DESC")
	private String COUNTRY_DESC;
	
	@Column(name="STATE_CODE")
	private String STATE_CODE;
	
	@Column(name="STATE_DESC")
	private String STATE_DESC;
	
	@Column(name="CITY_CODE")
	private String CITY_CODE;
	
	@Column(name="CITY_DESC")
	private String CITY_DESC;
}
