package com.optimus.idfc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication
public class MasterDetailsApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(MasterDetailsApplication.class, args);
	}

}
