package com.optimus.idfc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor

@Table(name="LINE_OF_BUSINESS")
public class LineOfBusiness {
	
	@Id
	@Column(name="LINE_OF_BUSINESS_ID")
	private String LineOfBusinessId;
	
	@Column(name="LINE_OF_BUSINESS_NAME")
	private String LineOfBusinessName;
	
	
	
	
	
	

}
