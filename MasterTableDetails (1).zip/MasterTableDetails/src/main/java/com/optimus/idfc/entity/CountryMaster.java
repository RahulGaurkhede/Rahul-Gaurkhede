package com.optimus.idfc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="Country_Master")
public class CountryMaster {
	
	@Id
	@Column(name="INST_NO")
	private String INST_NO;
	
	@Column(name="CODE")
	private String CODE;
	
	@Column(name="ISO_COUNTRY_CODE")
	private String ISO_COUNTRY_CODE;
	
	@Column(name="ISO_COUNTRY_NUMBER")
	private String ISO_COUNTRY_NUMBER;
	
	@Column(name="NAME")
	private String NAME;
	
	@Column(name="NAME_2")
	private String NAME_2;
	
	@Column(name="CURRENCY")
	private String CURRENCY;
	
	@Column(name="MON_EXP_IND")
	private String MON_EXP_IND;
	
	@Column(name="STATUS")
	private String STATUS;
	
	@Column(name="WEEK_END_DAY_1")
	private String WEEK_END_DAY_1;
	
	@Column(name="WEEK_END_DAY_2")
	private String WEEK_END_DAY_2;
	
	@Column(name="SECTOR_GROUP_1")
	private String SECTOR_GROUP_1;
	
	@Column(name="SECTOR_GROUP_2")
	private String SECTOR_GROUP_2;
	
	@Column(name="SECTOR_GROUP_3")
	private String SECTOR_GROUP_3;
	
	@Column(name="FX_DIR_LIMIT_AMT")
	private String FX_DIR_LIMIT_AMT;
	
	@Column(name="FX_INDIR_LIMIT_AMT")
	private String FX_INDIR_LIMIT_AMT;
	
	@Column(name="MM_DIR_LIMIT_AMT")
	private String MM_DIR_LIMIT_AMT;
	
	@Column(name="MM_INDIR_LIMIT_AMT")
	private String MM_INDIR_LIMIT_AMT;
	
	@Column(name="ISD_CODE")
	private String ISD_CODE;
	
	@Column(name="COUN_IN_CAUTION")
	private String COUN_IN_CAUTION;
	
	
	
	
	
	
	
	
	
	
	
	

}
