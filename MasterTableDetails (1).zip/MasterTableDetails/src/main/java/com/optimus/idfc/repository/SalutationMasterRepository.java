package com.optimus.idfc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.optimus.idfc.entity.SalutationMaster;

public interface SalutationMasterRepository  extends JpaRepository<SalutationMaster, String> {

}
