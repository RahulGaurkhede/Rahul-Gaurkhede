package com.optimus.idfc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor

@Table(name="Pin_Code_Master")
public class PinCodeMaster {
	
	@Id
	@Column(name="INST_NO")
	private String INST_NO;
	
	@Column(name="PIN_CODE")
	private String PIN_CODE;
	
	@Column(name="CITY_CODE")
	private String CITY_CODE;
	
	@Column(name="STATE_CODE")
	private String STATE_CODE;
	
	@Column(name="DESCRIPTION")
	private String DESCRIPTION;
	
	@Column(name="STATUS")
	private String STATUS;
	
	
	
	

}
