package com.optimus.idfc.controller.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.any;
import static org.hamcrest.CoreMatchers.anything;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mockitoSession;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.Answer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.optimus.idfc.Response.MasterDetailResponse;
import com.optimus.idfc.Response.MasterDetailResponse.MassageBody;
import com.optimus.idfc.Response.MasterDetailResponse.MassageHeader;
import com.optimus.idfc.controller.MasterDetailsController;
import com.optimus.idfc.entity.BusinessTypeMaster;
import com.optimus.idfc.entity.DocumentMaster;
import com.optimus.idfc.service.MasterDetailsService;



@ExtendWith(MockitoExtension.class)
public class MasterDetailsControllerTest {

	@Mock
	private MasterDetailsController masterDetailsController;
	
	@Mock
	private MasterDetailsService masterDetailsService;
	
	@Mock
	private MasterDetailResponse masterDetailResponse;
	
	@Mock
	private MassageHeader massageHeader;
	
	@Mock
	private MassageBody massageBody;
		
	public ResponseEntity<MasterDetailResponse>  masterDetailsResponse() {
		List<DocumentMaster> documentMasterList= new ArrayList<DocumentMaster>();
		documentMasterList.add(DocumentMaster.builder().DocumentId("PAN Card").DocumentName("PAN Card").build());
		documentMasterList.add(DocumentMaster.builder().DocumentId("passport").DocumentName("passport").build());
		documentMasterList.add(DocumentMaster.builder().DocumentId("Driving License").DocumentName("Driving License").build());
		documentMasterList.add(DocumentMaster.builder().DocumentId("GST Certificate").DocumentName("GST Certificate").build());
		//List<Tutorial> tutorials = new ArrayList<Tutorial>();
		
		List<BusinessTypeMaster> businessTypeMasteList = new ArrayList<BusinessTypeMaster>();
		businessTypeMasteList.add(BusinessTypeMaster.builder().businessTypeId("Sole Proprietorships").businessType("Sole Proprietorships").build());
		businessTypeMasteList.add(BusinessTypeMaster.builder().businessTypeId("Partnerships").businessType("Partnerships").build());
		businessTypeMasteList.add(BusinessTypeMaster.builder().businessTypeId("Limited Liability Companies").businessType("Limited Liability Companies").build());
		businessTypeMasteList.add(BusinessTypeMaster.builder().businessTypeId("Corporations").businessType("Corporations").build());
		
		massageHeader = MassageHeader.builder().code("200").build();
		massageBody = MassageBody.builder().documentList(documentMasterList).busunesssTypeList(businessTypeMasteList).build();
		
		masterDetailResponse = MasterDetailResponse.builder().massageHeader(massageHeader).massageBody(massageBody).build();
		
		
		
		return new ResponseEntity<MasterDetailResponse>(masterDetailResponse, HttpStatus.OK);
		
	}
	
	
	
	  @Test 
	  void getMasterDetail_Success() throws Exception{
		  		  
		  Mockito.when(masterDetailsService.getMasterDetail()).thenReturn(masterDetailResponse);
		  
		  Mockito.when(masterDetailResponse.getMassageHeader()).thenReturn(massageHeader);
		  
		  Mockito.when(masterDetailResponse.getMassageHeader().getCode()).thenReturn("200");
		  
		  String s1 = "";
		  String s2 = "";
		  
		  assertThat(s1.equalsIgnoreCase(s2));
		  
		  assertEquals(masterDetailsController.getMasterDetail(), masterDetailsResponse());
	  
	  }
	 
	
	
		
	}

