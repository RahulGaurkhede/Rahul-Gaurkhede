package com.idfc.caapp.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.idfc.caapp.mule.response.VerifyVoterIdResponse;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdDetails;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdMessageBody;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdMessageHeader;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VoterIdVerificationResp;
import com.idfc.caapp.service.VoterIdService;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse.CustomerVoterIdDetails;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse.CustomerVoterIdMessageBody;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse.CustomerVoterIdMessageHeader;

@WebMvcTest(value = CustomerVoterIdController.class)
public class CustomerVoterIdControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private VoterIdService voterIdService;

	@Test
	void getVoterIdDetailsTest_success() throws Exception {

//		CustomerVoterIdResponse customerVoterIdResponse = CustomerVoterIdResponse.builder()
//
//				.msgHdr(CustomerVoterIdMessageHeader.builder().code("200").build())
//				.msgBdy(CustomerVoterIdMessageBody.builder()
//						.result(CustomerVoterIdDetails.builder().name("").rln_name("").rln_type("").gender("M")
//								.district("Nagpur").ac_name("").pc_name("").state("Maharashtra").epic_no("KSG3221710")
//								.dob("10-06-1985").age("36").ac_no("").st_code("").house_no("").build())
//						.request_id("8124315d").status_code("101").build())
//				.build();
		
		VerifyVoterIdResponse verifyVoterIdResponse = VerifyVoterIdResponse.builder()
				.voterIdVerificationResp(VoterIdVerificationResp.builder().msgHdr(VerifyVoterIdMessageHeader.builder().rslt("").build())
						.msgBdy(VerifyVoterIdMessageBody.builder().result(VerifyVoterIdDetails.builder()
								.name("").rln_name("").gender("M").district("Nagpur").state("Maharashtra")
								.epic_no("KSG3221710").dob("10-06-1985").age("36").house_no("").build())
								.request_id("8124315d").status_code("101").build()).build()).build();

		when(voterIdService.verifyVoterIdDetails(Mockito.anyString())).thenReturn(verifyVoterIdResponse);

		mockMvc.perform(get("/customer/VoterID?voterId=123")).andDo(print()).andExpect(status().isOk());

	}

	@Test
	void getCustomerVoterIdDetailsTest_Failed() throws Exception {

		VerifyVoterIdResponse verifyVoterIdResponse = VerifyVoterIdResponse.builder()
				.voterIdVerificationResp(VoterIdVerificationResp.builder().msgHdr(VerifyVoterIdMessageHeader.builder().rslt("").build())
						.msgBdy(VerifyVoterIdMessageBody.builder().result(VerifyVoterIdDetails.builder()
								.name("").rln_name("").gender("M").district("Nagpur").state("Maharashtra")
								.epic_no("KSG3221710").dob("10-06-1985").age("36").house_no("").build())
								.request_id("8124315d").status_code("101").build()).build()).build();

		when(voterIdService.verifyVoterIdDetails(Mockito.anyString())).thenReturn(verifyVoterIdResponse);

		mockMvc.perform(get("/customer/VoterID1?voterId=1234")).andDo(print()).andExpect(status().isNotFound());
	}

//	@Test
//	void getVoterIdDetailsTestSuccess() throws Exception{
//		
//		mockMvc.perform(MockMvcRequestBuilders.get("/customer/verifyVoterId")).andDo(print()).andExpect(status().isOk());
//	}
//	
//	@Test
//	void getVoterIdDetailsFailure() throws Exception{
//		
//		mockMvc.perform(get("/customer/verifyVoterId")).andDo(print()).andExpect(status().isNotFound());
//	}

}
