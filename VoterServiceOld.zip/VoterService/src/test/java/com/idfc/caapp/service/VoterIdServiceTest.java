package com.idfc.caapp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.idfc.caapp.mule.response.VerifyVoterIdRequest;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.Frm;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.HeaderFields;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.VerifyVoterIdReqMsgBdy;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.VerifyVoterIdReqMsgHdr;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.VoterIdVerificationReq;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdDetails;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdMessageBody;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdMessageHeader;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VoterIdVerificationResp;
import com.idfc.caapp.request.VoterIdRequest;
import com.idfc.caapp.transformer.CustomerTransformer;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse.CustomerVoterIdDetails;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse.CustomerVoterIdMessageBody;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class VoterIdServiceTest {

	@InjectMocks
	private VoterIdService voterIdService;

	@Mock
	private IntegrationService integrationService;

	@Mock
	private CustomerTransformer customerTransformer;

	@Test
	void getCustomerVoterIdDetails_Success() {

		VoterIdRequest voterIdRequest = VoterIdRequest.builder().voterId("V111").epicNumber("SHA4722088").build();
		System.out.println("99999");
		when(customerTransformer.prepareVerifyVoterIdRequest(Mockito.anyObject()))
				.thenReturn(getVerifyVoterIdRequest(voterIdRequest.getEpicNumber()));

		when(integrationService.getverifyVoterIdDetails(Mockito.anyObject()))
				.thenReturn(getverifyVoterIdResponse(voterIdRequest.getEpicNumber()));

		VerifyVoterIdResponse response = voterIdService.verifyVoterIdDetails(voterIdRequest.getEpicNumber());
		VerifyVoterIdDetails customerresponse = response.getVoterIdVerificationResp().getMsgBdy().getResult();

		assertEquals(voterIdRequest.getEpicNumber(), customerresponse.getSt_code());

	}

	@Test
	void getCustomerVoterIdDetails_Failure() {

		VoterIdRequest voterIdRequest = VoterIdRequest.builder().voterId("V111").epicNumber("101").build();

		Mockito.when(customerTransformer.prepareVerifyVoterIdRequest(Mockito.anyObject()))
				.thenReturn(getVerifyVoterIdRequest(voterIdRequest.getEpicNumber()));

		Mockito.when(integrationService.getverifyVoterIdDetails(Mockito.anyObject()))
				.thenReturn(getverifyVoterIdResponse(voterIdRequest.getEpicNumber()));

		VerifyVoterIdResponse response = voterIdService.verifyVoterIdDetails(voterIdRequest.getVoterId());
		VerifyVoterIdDetails customerresponse = response.getVoterIdVerificationResp().getMsgBdy().getResult();

		// CustomerVoterIdMessageBody bdy = response.getMsgBdy();

		assertEquals(voterIdRequest.getEpicNumber(), customerresponse.getSt_code());

	}

	private VerifyVoterIdRequest getVerifyVoterIdRequest(String epicNumber) {

		return VerifyVoterIdRequest.builder()
				.voterIdVerificationReq(VoterIdVerificationReq.builder()
						.msgHdr(VerifyVoterIdReqMsgHdr.builder().frm(Frm.builder().id("").build())
								.hdrFlds(HeaderFields.builder().msgId("111").timestamp("").build()).build())
						.msgBdy(VerifyVoterIdReqMsgBdy.builder().consent("").epicNumber(epicNumber).build()).build())
				.build();

	}

	private VerifyVoterIdResponse getverifyVoterIdResponse(String epicNumber) {

		VerifyVoterIdMessageHeader msgHdr = VerifyVoterIdMessageHeader.builder().rslt("OK").build();

		VerifyVoterIdMessageBody msgBdy = VerifyVoterIdMessageBody.builder().request_id("").status_code("101").build();

		VoterIdVerificationResp voterIdVerificationResp = VoterIdVerificationResp.builder().msgHdr(msgHdr)
				.msgBdy(msgBdy).build();

		return VerifyVoterIdResponse.builder().voterIdVerificationResp(voterIdVerificationResp).build();
	}

}

// CustomerVoterIdResponse response =
// voterIdService.verifyVoterIdDetails(voterIdRequest.getEpicNumber());
//String epic_no = response.
// CustomerVoterIdMessageBody bdy = response.getMsgBdy();