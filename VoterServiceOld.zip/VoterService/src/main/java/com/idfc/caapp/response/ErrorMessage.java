package com.idfc.caapp.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
//@SuppressWarnings("unused")
@Builder
public class ErrorMessage {

	private List<ApiError> errors;

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class ApiError {

		private ErrorMessageHeader msg_Hdr;
		private ErrorMessageBody msg_Bdy;

	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	@JsonPropertyOrder({ "errorCode", "status", "type" })
	public static class ErrorMessageHeader {
		@JsonProperty(value = "error-code")
		private String errorCode;
		private String status;
		private String type;

	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class ErrorMessageBody {
		private String message;
		private String detail;
	}

}
