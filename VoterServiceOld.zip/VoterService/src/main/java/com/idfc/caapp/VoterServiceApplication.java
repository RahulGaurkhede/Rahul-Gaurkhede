package com.idfc.caapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoterServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoterServiceApplication.class, args);
	}

}
