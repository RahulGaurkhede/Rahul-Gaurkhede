package com.idfc.caapp.mule.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class VerifyVoterIdResponse {

	private VoterIdVerificationResp voterIdVerificationResp;

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	public static class VoterIdVerificationResp {
		private VerifyVoterIdMessageHeader msgHdr;
		private VerifyVoterIdMessageBody msgBdy;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	public static class VerifyVoterIdMessageHeader {
		private String rslt;
	//	private List<ErrorType> error;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	public static class VerifyVoterIdMessageBody {
		private VerifyVoterIdDetails result;
		private String request_id;
		private String status_code;

	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	public static class VerifyVoterIdDetails {
		private String name;
		private String rln_name;
		private String rln_type;
		private String gender;
		private String district;
		private String ac_name;
		private String pc_name;
		private String state;
		private String epic_no;
		private String dob;
		private String age;
		private String part_no;
		private String slno_inpart;
		private String ps_name;
		private String part_name;
		private String last_update;
		private String ps_lat_long;
		private String rln_name_v1;
		private String rln_name_v2;
		private String rln_name_v3;
		private String section_no;
		private String id;
		private String name_v1;
		private String name_v2;
		private String name_v3;
		private String ac_no;
		private String st_code;
		private String house_no;

	}

//	@Data
//	@AllArgsConstructor
//	@NoArgsConstructor
//	@Builder
//	public static class ErrorType {
//		private String cd;
//		private String rsn;
//
//	}

}

