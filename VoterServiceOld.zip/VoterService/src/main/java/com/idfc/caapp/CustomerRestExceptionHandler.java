package com.idfc.caapp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.idfc.caapp.response.ErrorMessage;
import com.idfc.caapp.response.ErrorMessage.ApiError;
import com.idfc.caapp.response.ErrorMessage.ErrorMessageBody;
import com.idfc.caapp.response.ErrorMessage.ErrorMessageHeader;
import com.idfc.caapp.response.MessageHeader;
import com.idfc.caapp.response.MessageResponse;

@ControllerAdvice
public class CustomerRestExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler({ VerifyVoterIdException.class })
	public ResponseEntity<?> customerVoterIdException(VerifyVoterIdException ex) {

		List<ApiError> errorList = new ArrayList<>();

		ApiError error = ApiError.builder()
				.msg_Hdr(ErrorMessageHeader.builder().errorCode("CUSTOMER-EXP-0001")
						.status(String.valueOf(ex.getCode())).type("VoterIdException").build())
				.msg_Bdy(ErrorMessageBody.builder().message("Invalid Request")
						.detail("Mandatory fields are not specified.").build())
				.build();
		errorList.add(error);

		ErrorMessage errors = ErrorMessage.builder().errors(errorList).build();
		
		return new ResponseEntity<>(errors,HttpStatus.valueOf(ex.getCode()));

//		ErrorMessage errorMessage = ErrorMessage.builder().status(ex.getError()).erroorMessage(ex.getErrorMessage())
//				.build();
//		MessageResponse<?> messageResponse = MessageResponse.builder()
//				.messageHeader(MessageHeader.builder().code(Integer.toString(ex.getCode())).build())
//				.messageBody(errorMessage).build();
		
//		return new ResponseEntity<MessageResponse>(messageResponse, HttpStatus.valueOf(ex.getCode()));
	}

}
