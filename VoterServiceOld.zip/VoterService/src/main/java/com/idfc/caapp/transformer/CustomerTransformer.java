package com.idfc.caapp.transformer;

import java.time.LocalDateTime;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Component;

import com.idfc.caapp.mule.response.VerifyVoterIdRequest;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.Frm;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.HeaderFields;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.VerifyVoterIdReqMsgBdy;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.VerifyVoterIdReqMsgHdr;
import com.idfc.caapp.mule.response.VerifyVoterIdRequest.VoterIdVerificationReq;
import com.idfc.caapp.request.VoterIdRequest;
import com.idfc.caapp.util.DateFormatUtility;

@Component
public class CustomerTransformer {
	
	public VerifyVoterIdRequest prepareVerifyVoterIdRequest(VoterIdRequest VoterIdRequest) {
		
		String msgId = RandomStringUtils.randomNumeric(10);
		String timestamp = DateFormatUtility.dateTimeFormat(LocalDateTime.now().plusMinutes(0));
		
		VerifyVoterIdReqMsgHdr msgHdr = VerifyVoterIdReqMsgHdr.builder().frm(Frm.builder().id("ABC").build())
				.hdrFlds(HeaderFields.builder().msgId(msgId).timestamp(timestamp).build()).build();
	
		VerifyVoterIdReqMsgBdy msgBdy = VerifyVoterIdReqMsgBdy.builder().epicNumber(VoterIdRequest.getEpicNumber())
				.consent("").build();
		
		return VerifyVoterIdRequest.builder()
				.voterIdVerificationReq(VoterIdVerificationReq.builder().msgHdr(msgHdr).msgBdy(msgBdy).build()).build();
	
	}

}

