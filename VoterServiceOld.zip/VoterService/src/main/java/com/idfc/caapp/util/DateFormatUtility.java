package com.idfc.caapp.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

import lombok.NoArgsConstructor;

@Component
@NoArgsConstructor
public class DateFormatUtility {
	
	private static final String DDMMYYYY = "ddMMyyyy";
	private static final String YYYYMMDD_T_HHMMSS = "yyyy-MM-dd'T'HH:mm:ss";
	
	public static String dateFormatddmmyyyy(LocalDateTime localDateTime) {
		return localDateTime.format(DateTimeFormatter.ofPattern(DDMMYYYY));
	}
	
	public static String dateTimeFormat(LocalDateTime localDateTime) {
		return localDateTime.format(DateTimeFormatter.ofPattern(YYYYMMDD_T_HHMMSS));
	}

}

