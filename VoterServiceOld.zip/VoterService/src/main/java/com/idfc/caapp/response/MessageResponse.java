package com.idfc.caapp.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
//@SuppressWarnings({"unused", "hiding"})
@Builder
public class MessageResponse<T> {

	@JsonProperty(value = "msg_hdr")
	private MessageHeader messageHeader;

	@JsonProperty(value = "msg_body")
	private T messageBody;

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class MessageHeader {

		private int code;
	}

}
