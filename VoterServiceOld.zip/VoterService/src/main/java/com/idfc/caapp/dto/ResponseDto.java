package com.idfc.caapp.dto;


public class ResponseDto {

}
