package com.idfc.caapp.error;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VoterIdVerificationESBErrorResp {

	private VoterIdVerificationErrorResp voterIdVerificationErrorResp;

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class VoterIdVerificationErrorResp {

		private ESBErrorMessageHeader msgHdr;
		private ESBErrorMessageBody msgBdy;
	}

	@Data
	@Builder
	public static class ESBErrorMessageBody {

		private String msg;
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	@Builder
	public static class ESBErrorMessageHeader {

		private String rslt;
		private List<ErrorType> error;
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	@Builder
	public static class ErrorType {

		private String cd;
		private String rsn;
		private Srvc srvc;

	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	@Builder
	public static class Srvc {

		private String nm;
		private String cntxt;
		private Actn actn;
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@ToString
	@Builder
	public static class Actn {

		private String paradigm;
		private String nm;
		private String vrsn;
	}
}
