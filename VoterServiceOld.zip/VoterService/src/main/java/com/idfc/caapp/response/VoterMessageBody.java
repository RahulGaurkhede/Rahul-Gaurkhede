package com.idfc.caapp.response;

import com.idfc.caapp.mule.response.VerifyVoterIdResponse.VerifyVoterIdDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("unused")
@Builder
public class VoterMessageBody {

	private String name;
	private String rln_name;
	private String rln_type;
	private String gender;
	private String district;
	private String ac_name;
	private String pc_name;
	private String state;
	private String epic_no;
	private String dob;
	private String age;
	private String part_no;
	private String slno_inpart;
	private String ps_name;
	private String part_name;
	private String last_update;
	private String ps_lat_long;
	private String rln_name_v1;
	private String rln_name_v2;
	private String rln_name_v3;
	private String section_no;
	private String id;
	private String name_v1;
	private String name_v2;
	private String name_v3;
	private String ac_no;
	private String st_code;
	private String house_no;

	public static VoterMessageBody getVerifyVoterIdDetails(VerifyVoterIdDetails verifyVoterIdDetails) {

		return VoterMessageBody.builder().name(verifyVoterIdDetails.getName())
				.rln_name(verifyVoterIdDetails.getRln_name()).rln_type(verifyVoterIdDetails.getRln_type())
				.gender(verifyVoterIdDetails.getGender()).district(verifyVoterIdDetails.getDistrict())
				.ac_name(verifyVoterIdDetails.getAc_name()).pc_name(verifyVoterIdDetails.getPc_name())
				.state(verifyVoterIdDetails.getState()).epic_no(verifyVoterIdDetails.getEpic_no())
				.dob(verifyVoterIdDetails.getDob()).age(verifyVoterIdDetails.getAge())
				.part_no(verifyVoterIdDetails.getPart_no()).slno_inpart(verifyVoterIdDetails.getSlno_inpart())
				.ps_name(verifyVoterIdDetails.getPs_name()).part_name(verifyVoterIdDetails.getPart_name())
				.last_update(verifyVoterIdDetails.getLast_update()).ps_lat_long(verifyVoterIdDetails.getPs_lat_long())
				.rln_name_v1(verifyVoterIdDetails.getRln_name_v1()).rln_name_v2(verifyVoterIdDetails.getRln_name_v2())
				.rln_name_v3(verifyVoterIdDetails.getRln_name_v3()).section_no(verifyVoterIdDetails.getSection_no())
				.id(verifyVoterIdDetails.getId()).name_v1(verifyVoterIdDetails.getName_v1())
				.name_v2(verifyVoterIdDetails.getName_v2()).name_v3(verifyVoterIdDetails.getName_v3())
				.ac_no(verifyVoterIdDetails.getAc_no()).st_code(verifyVoterIdDetails.getSt_code())
				.house_no(verifyVoterIdDetails.getHouse_no()).build();
	}

}
