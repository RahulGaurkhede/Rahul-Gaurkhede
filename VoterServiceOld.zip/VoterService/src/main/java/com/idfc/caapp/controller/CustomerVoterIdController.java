package com.idfc.caapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.idfc.caapp.VerifyVoterIdException;
import com.idfc.caapp.mule.response.VerifyVoterIdResponse;
//import com.idfc.caapp.mule.response.VerifyVoterIdExlResponse;
//import com.idfc.caapp.mule.response.VerifyVoterIdExlResponse.VerifyVoterIdExlDetails;
import com.idfc.caapp.request.VoterIdRequest;
import com.idfc.caapp.response.MessageResponse;
import com.idfc.caapp.response.VoterMessageBody;
import com.idfc.caapp.service.VoterIdService;
import com.idfc.caapp.voterIdDto.CustomerVoterIdResponse;

@RestController
public class CustomerVoterIdController {

	@Autowired
	private VoterIdService voterIdService;

	@GetMapping("/customer/VoterID")
	public VerifyVoterIdResponse getVoterIdDetails(@RequestParam(value = "voterId") String voterId) {

		VerifyVoterIdResponse verifyVoterIdResponse = voterIdService.verifyVoterIdDetails(voterId);

		return verifyVoterIdResponse;

	}

}

























////////// start previous code ////////
// VerifyVoterIdExlResponse response =
////////// voterIdService.verifyVoterIdDetails(voterId);
///////// end previos code /////////////////////

////////////// *********************//////////////////////

//	CustomerVoterIdResponse response = voterIdService.verifyVoterIdDetails(voterId);
//	return new ResponseEntity<>(response,HttpStatus.OK);

/////////////////// **********************////////////////////////
