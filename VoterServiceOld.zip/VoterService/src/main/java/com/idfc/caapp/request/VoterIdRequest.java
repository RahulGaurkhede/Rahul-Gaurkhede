package com.idfc.caapp.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("unused")
@Builder
public class VoterIdRequest {

	private String voterId;
	private String epicNumber;

}

