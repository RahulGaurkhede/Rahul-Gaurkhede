package com.idfc.caapp.voterIdDto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(Include.NON_NULL)
public class CustomerVoterIdResponse {

//	private CustomerVoterIdResp CustomerVoterIdResp;
//
//	@Data
//	@AllArgsConstructor
//	@NoArgsConstructor
//	@Builder
//	@JsonInclude(Include.NON_NULL)
//	public static class CustomerVoterIdResp {

		private CustomerVoterIdMessageHeader msgHdr;
		private CustomerVoterIdMessageBody msgBdy;

//	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonInclude(Include.NON_NULL)
	public static class CustomerVoterIdMessageHeader {
		private String code;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonInclude(Include.NON_NULL)
	public static class CustomerVoterIdMessageBody {
		private CustomerVoterIdDetails result;
		private String request_id;
		private String status_code;
	}

	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@JsonInclude(Include.NON_NULL)
	public static class CustomerVoterIdDetails {

		private String name;
		private String rln_name;
		private String rln_type;
		private String gender;
		private String district;
		private String ac_name;
		private String pc_name;
		private String state;
		private String epic_no;
		private String dob;
		private String age;
		private String part_no;
		private String slno_inpart;
		private String ps_name;
		private String part_name;
		private String last_update;
		private String ps_lat_long;
		private String rln_name_v1;
		private String rln_name_v2;
		private String rln_name_v3;
		private String section_no;
		private String id;
		private String name_v1;
		private String name_v2;
		private String name_v3;
		private String ac_no;
		private String st_code;
		private String house_no;
	}

}

