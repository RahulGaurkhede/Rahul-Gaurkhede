package com.optimus.idfc.controller.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.optimus.idfc.Response.MasterDetailResponse;
import com.optimus.idfc.Response.MasterDetailResponse.MassageBody;
import com.optimus.idfc.Response.MasterDetailResponse.MassageHeader;
import com.optimus.idfc.controller.MasterDetailsController;
import com.optimus.idfc.entity.BusinessTypeMaster;
import com.optimus.idfc.entity.DocumentMaster;



@ExtendWith(MockitoExtension.class)
public class MasterDetailsControllerTest {

	@InjectMocks
	private MasterDetailsController masterDetailsController;
	
	public MasterDetailResponse  masterDetailsResponse() {
		List<DocumentMaster> documentMasterList= new ArrayList<DocumentMaster>();
		documentMasterList.add(DocumentMaster.builder().DocumentId("PAN Card").DocumentName("PAN Card").build());
		documentMasterList.add(DocumentMaster.builder().DocumentId("passport").DocumentName("passport").build());
		documentMasterList.add(DocumentMaster.builder().DocumentId("Driving License").DocumentName("Driving License").build());
		documentMasterList.add(DocumentMaster.builder().DocumentId("GST Certificate").DocumentName("GST Certificate").build());
		//List<Tutorial> tutorials = new ArrayList<Tutorial>();
		
		List<BusinessTypeMaster> businessTypeMasteList = new ArrayList<BusinessTypeMaster>();
		businessTypeMasteList.add(BusinessTypeMaster.builder().businessTypeId("Sole Proprietorships").businessType("Sole Proprietorships").build());
		businessTypeMasteList.add(BusinessTypeMaster.builder().businessTypeId("Partnerships").businessType("Partnerships").build());
		businessTypeMasteList.add(BusinessTypeMaster.builder().businessTypeId("Limited Liability Companies").businessType("Limited Liability Companies").build());
		businessTypeMasteList.add(BusinessTypeMaster.builder().businessTypeId("Corporations").businessType("Corporations").build());
		
		MassageHeader massageHeader = MassageHeader.builder().code("200").build();
		MassageBody massageBody = MassageBody.builder().documentList(documentMasterList).busunesssTypeList(businessTypeMasteList).build();
		
		MasterDetailResponse masterDetailResponse = MasterDetailResponse.builder().massageHeader(massageHeader).massageBody(massageBody).build();
		
		return masterDetailResponse;
		
	}
	
	
	/*
	 * @Test void getMasterDetail_Success() throws Exception{
	 * 
	 * Mockito.when(customerTransformer.prepareVerifyPhoneRequest(Mockito.anyObject(
	 * ))).thenReturn(getVerifyPhoneRequest());
	 * 
	 * Mockito.when(integrationService.getPhoneNumberDetailResponce(Mockito.
	 * anyObject())).thenReturn(createTestSucessResponce());
	 * 
	 * VerifyPhoneNumberResponse verifyPhoneNumberResponse =
	 * customerMobileNumberService.searchCustomerDetail(phoneNumberRequest);
	 * MuleMessageResponseHeader muleMessageResponseHeader =
	 * verifyPhoneNumberResponse.getMuleDeduplicateByMobileResponce().
	 * getMessageResponseHeader(); MuleMessageResponseBody muleMessageResponseBody =
	 * verifyPhoneNumberResponse.getMuleDeduplicateByMobileResponce().
	 * getMessageResponseBody();
	 * 
	 * //Mockito.when(customerMobileNumberService.searchCustomerDetail(Mockito.
	 * anyObject())).thenReturn(createVerifyPhoneNumberResponse.createTestResponce()
	 * );
	 * 
	 * assertEquals(custList, muleMessageResponseBody.getMatchResultList());
	 * assertEquals("OK", muleMessageResponseHeader.getResult());
	 * 
	 * }
	 */
	
	
		
	}

