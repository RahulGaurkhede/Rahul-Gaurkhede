package com.optimus.idfc.Response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.optimus.idfc.entity.BusinessTypeMaster;
import com.optimus.idfc.entity.DocumentMaster;
import com.optimus.idfc.entity.LineOfBusiness;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MasterDetailResponse {
	
	@JsonProperty(value="msg_hdr")
	private MassageHeader massageHeader;
	
	@JsonProperty(value="msg_body")
	private MassageBody massageBody;

	
	@Getter
	@Setter
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class MassageHeader{
		
		private String code;
		
	}
	
	@Getter
	@Setter
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	@ToString
	public static class MassageBody{
		
		private List<DocumentMaster> documentList;
		
		private List<BusinessTypeMaster> busunesssTypeList;
		
		private List<LineOfBusiness> lineOfBusinessList;
		
		
	}
}

