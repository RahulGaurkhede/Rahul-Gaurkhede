package com.optimus.idfc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity
@Table(name="BUSINESS_TYPE_MASTER")
public class BusinessTypeMaster {
	
	@Id
	@Column(name="BUSINESS_TYPE_ID")
	private String businessTypeId;
	
	@Column(name="BUSINESS_TYPE")
	private String businessType;

}
