package com.optimus.idfc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.optimus.idfc.entity.DocumentMaster;

@Repository
public interface DocumentMasterRepository extends JpaRepository<DocumentMaster, String>{

}
