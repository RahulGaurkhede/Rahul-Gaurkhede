package com.optimus.idfc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.optimus.idfc.VerifyMasterdetailException;
import com.optimus.idfc.Response.MasterDetailResponse;
import com.optimus.idfc.Response.MasterDetailResponse.MassageBody;
import com.optimus.idfc.Response.MasterDetailResponse.MassageHeader;
import com.optimus.idfc.entity.BusinessTypeMaster;
import com.optimus.idfc.entity.DocumentMaster;
import com.optimus.idfc.entity.LineOfBusiness;
import com.optimus.idfc.repository.BusinessTypeMasterRepository;
import com.optimus.idfc.repository.DocumentMasterRepository;
import com.optimus.idfc.repository.LineOfBusinessRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class MasterDetailsService {
	
	@Autowired
	private DocumentMasterRepository documentMasterRepository;
	
	@Autowired
	private BusinessTypeMasterRepository businessTypeMasterRepository;
	
	@Autowired
	private LineOfBusinessRepository lineOfBusinessRepository;
	
	private MassageHeader massageHeader;
	private MassageBody massageBody;
	private MasterDetailResponse masterDetailResponse;

	//@CircuitBreaker(name = "master-detail-service", fallbackMethod = "masterdetailServiceMethod")
	public MasterDetailResponse getMasterDetail() {
		List<DocumentMaster> documentMasterList= new ArrayList<DocumentMaster>();
	
		List<BusinessTypeMaster> businessTypeMasteList = new ArrayList<BusinessTypeMaster>();
		List<LineOfBusiness> lineOfBusinessList = new ArrayList<LineOfBusiness>();

		documentMasterRepository.findAll().forEach(documentMasterList::add);
		businessTypeMasterRepository.findAll().forEach(businessTypeMasteList::add);
		lineOfBusinessRepository.findAll().forEach(lineOfBusinessList::add);
		
		massageHeader = MassageHeader.builder().code("200").build();
		massageBody = MassageBody.builder().documentList(documentMasterList).busunesssTypeList(businessTypeMasteList).lineOfBusinessList(lineOfBusinessList).build();
		
		masterDetailResponse = MasterDetailResponse.builder().massageHeader(massageHeader).massageBody(massageBody).build();
		
		return masterDetailResponse;
		
	}
	
	/*
	 * public VerifyMasterdetailException masterdetailServiceMethod(Exception e) {
	 * throw new VerifyMasterdetailException(HttpStatus.NOT_FOUND.value(), "error",
	 * "Master Detail Service is down"); }
	 */
	
}
