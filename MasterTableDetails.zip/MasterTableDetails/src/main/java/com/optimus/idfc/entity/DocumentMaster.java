package com.optimus.idfc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="DOCUMENT_MASTER")
public class DocumentMaster {

	@Id
	@Column(name="DOCUMENT_ID")
	private String DocumentId;
	
	@Column(name="DOCUMENT_NAME")
	private String DocumentName;
	
}
