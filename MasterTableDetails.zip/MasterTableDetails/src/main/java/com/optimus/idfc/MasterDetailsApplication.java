package com.optimus.idfc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasterDetailsApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(MasterDetailsApplication.class, args);
	}

}
